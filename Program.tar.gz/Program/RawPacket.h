/*
 * RawPacket.h
 *
 *  Created on: Oct 3, 2015
 *      Author: stud
 */

#ifndef RAWPACKET_H_
#define RAWPACKET_H_
#include <cstdlib>
#include <stdint.h>

typedef std::vector< uint8_t > RawPacket;



#endif /* RAWPACKET_H_ */
